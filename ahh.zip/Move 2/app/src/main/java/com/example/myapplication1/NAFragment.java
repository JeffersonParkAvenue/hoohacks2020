package com.example.myapplication1;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;

public class NAFragment extends Fragment {

    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_second, container, false);
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        view.findViewById(R.id.button_second).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NavHostFragment.findNavController(NAFragment.this)
                        .navigate(R.id.action_SecondFragment_to_FirstFragment);
            }
        });

    }
});

        view.findViewById(R.id.USA).setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        NavHostFragment.findNavController(NAFragment.this)
        .navigate(R.id.action_NAFragment_to_usaFragment);
        }
        });

        view.findViewById(R.id.Mexico).setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        NavHostFragment.findNavController(NAFragment.this)
        .navigate(R.id.action_NAFragment_to_mexicoFragment);
        }
        });

        view.findViewById(R.id.Canada).setOnClickListener(new View.OnClickListener() {
@Override
public void onClick(View view) {

        NavHostFragment.findNavController(NAFragment.this)
        .navigate(R.id.action_NAFragment_to_canadaFragment);
        }
        });
    }
}
